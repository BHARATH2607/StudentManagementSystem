﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyProjects
{
    class Manage
    {
        List<StudentEntity> ls = new List<StudentEntity>();
        private Student sd = new Student();
        StudentEntity e = new StudentEntity();
      
        public void showMain()
        {
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("\t\t\t\t*****----Welcome to Student Management System----*****");
            Console.WriteLine("1.Add Student Information " +
                "2.View Student Information " +
                "3.Modify Student Information " +
                "4.Delete Student Information " +
                "5.Exit");

            Console.WriteLine();
            Console.WriteLine("Enter your choice");
            int i = int.Parse(Console.ReadLine());
            switch (i)
            {
                case 1:
                    AddStudent();
                    break;

                case 2:
                    ViewStudent();
                    break;

                case 3:
                    EditStudent();
                    break;

                case 4:
                    DeleteStudent();
                    break;

                case 5:
                    Exit();
                    break;

                default:
                    Console.WriteLine("Invalid Choice");
                    break;
            }
            Console.ReadKey();
        }

        public void AddStudent()
        {
            StudentEntity e = new StudentEntity();

            Console.WriteLine();
            Console.WriteLine("1.Enter Student Information 2.Return to Previous Menu");
            Console.WriteLine();
            Console.WriteLine("Enter your choice: ");
            try
            {
                int i3 = int.Parse(Console.ReadLine());
                switch (i3)
                {
                    case 1:

                        Console.WriteLine("Please enter the student number you want to add:");
                        int id = int.Parse(Console.ReadLine());
                        e.Id = id;

                        Console.Write("Enter Name: ");
                        string n = Console.ReadLine();
                        e.Name = n;

                        Console.Write("Enter 0 for Male & 1 for Female: ");
                        int g = int.Parse(Console.ReadLine());
                        if (g == 0)
                            e.Gender = "Male";
                        else
                            e.Gender = "Female";

                        Console.Write("Enter Age: ");
                        int a = int.Parse(Console.ReadLine());
                        e.Age = a;

                        Console.Write("Enter Fees: ");
                        float f = float.Parse(Console.ReadLine());
                        e.Fees = f;

                        Console.WriteLine();
                        Console.WriteLine("Information has been successfully Added!");
                        Console.WriteLine();
                        ls.Add(e);

                        sd.Add(ls);
                        AddStudent();
                        break;

                    case 2:
                        showMain();
                        break;

                    default:
                        Console.WriteLine("Invalid Choice");
                        break;
                }
            }
            catch(Exception ob)
            {
                Console.WriteLine(ob.Message);
            }
        }

        public void ViewStudent()
        {
            Console.WriteLine();
            Console.WriteLine("1.View According to Student Id 2.Return to Previous Menu");
            Console.WriteLine();
            Console.WriteLine("Enter your choice: ");
            try
            {
                int i2 = int.Parse(Console.ReadLine());
                switch (i2)
                {
                    case 1:
                        sd.findEntityByID(ls);
                        ViewStudent();
                        break;

                    case 2:
                        showMain();
                        break;

                    default:
                        Console.WriteLine("Invalid Choice");
                        break;
                }
            }
            catch (Exception ob)
            {
                Console.WriteLine(ob.Message);
            }
        }

        public void EditStudent()
        {
            Console.WriteLine();
            Console.WriteLine("1.Enter Student Number To be modified 2.Return to Previous Menu");
            Console.WriteLine();
            Console.WriteLine("Enter your choice: ");
            try
            {
                int i4 = int.Parse(Console.ReadLine());
                switch (i4)
                {
                    case 1:
                        //Enter student information

                        Console.WriteLine("Please enter the student number you want to modify:");
                        int id = int.Parse(Console.ReadLine());

                        Console.WriteLine("Please enter the Name: ");
                        string name = Console.ReadLine();

                        Console.WriteLine("Please enter the Gender: ");
                        string gender = Console.ReadLine();

                        Console.WriteLine("Please enter the Age: ");
                        int age = int.Parse(Console.ReadLine());

                        Console.WriteLine("Please enter the Fees: ");
                        int fee = int.Parse(Console.ReadLine());

                        sd.EditStudentByID(id, name, gender, age, fee, ls);
                        EditStudent();
                        break;

                    case 2:
                        showMain();
                        break;

                    default:
                        Console.WriteLine("Invalid Choice");
                        break;
                }
            }
            catch (Exception ob)
            {
                Console.WriteLine(ob.Message);
            }
        }

        public void DeleteStudent()
        {
            Console.WriteLine();
            Console.WriteLine("1.Enter Student Id to be Deleted 2.Return to Previous Menu");
            Console.WriteLine();
            Console.WriteLine("Enter your choice: ");
            try
            {
                int i5 = int.Parse(Console.ReadLine());
                switch (i5)
                {
                    case 1:
                        Console.WriteLine("Please enter the Student Id you want to Delete: ");
                        int id = int.Parse(Console.ReadLine());
                        sd.RemoveStudent(id, ls);
                        DeleteStudent();
                        break;

                    case 2:
                        showMain();
                        break;

                    default:
                        Console.WriteLine("Invalid Choice");
                        break;
                }
            }
            catch(Exception ob)
            {
                Console.WriteLine(ob.Message);
            }
        }

        public void Exit()
        {
            Console.WriteLine();
            Console.WriteLine("*****---- THANK YOU ----*****");
            Console.WriteLine();
        }
    }
}
