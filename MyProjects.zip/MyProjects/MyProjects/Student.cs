﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyProjects
{
    class Student
    {
        public void findEntityByID(List<StudentEntity> ls)
        {
            Console.WriteLine("Please Enter the Student number: ");
            int id = int.Parse(Console.ReadLine());
            foreach(StudentEntity s in ls)
            {
                if(s.Id == id)
                {
                    Console.WriteLine("Sudent Information: " + ls[id].ToString());
                    break;
                }
            }
        }

        public void Add(List<StudentEntity> ls)
        {
            foreach (StudentEntity item in ls)
            {
                Console.WriteLine(item.ToString());
            }
        }

        public void EditStudentByID(int sId, string name, string gender, int age, int fees, List<StudentEntity> ls)
        {
            bool flag = false;
            for (int i = 0; i < ls.Count; i++)
            {
                if (ls[i] != null)
                {
                    if (ls[i].Id == sId)
                    {
                        flag = false;
                        ls[i].Name = name;
                        ls[i].Gender = gender;
                        ls[i].Age = age;
                        ls[i].Fees = fees;
                        break;

                    }
                    else
                    {
                        flag = true;
                    }

                }

            }
            if (flag)
            {
                Console.WriteLine("The system cannot modify this student number!");
            }

            Console.WriteLine("Modified Data: " + ls[sId].ToString());
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("Present Data");

            foreach (StudentEntity item in ls)
            {                
                Console.WriteLine(item.ToString());
            }
        }

        public void RemoveStudent(int sid, List<StudentEntity> ls)
        {
            for (int i = 0; i < ls.Count; i++)
            {
                if (ls[i] == null)
                {
                    continue;
                }
                if (ls[i] != null)
                {
                    if (ls[i].Id == sid)
                    {
                        ls[i] = ls[i + 1];
                        ls[i + 1] = null;
                        Console.WriteLine();
                        Console.WriteLine("Successfully Deleted!");
                        Console.WriteLine();
                    }
                }
            }

            foreach(StudentEntity item in ls)
            {
                if (item != null)
                {
                    Console.WriteLine(item.ToString());
                }
            }
        }
    }
}
