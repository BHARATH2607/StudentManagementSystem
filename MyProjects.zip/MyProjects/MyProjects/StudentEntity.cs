﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyProjects
{
    public class StudentEntity
    {
        private int _id;
        private string _name;
        private string _gender;
        private int _age;
        private float _fees;

        public int Id
        {
            get
            {
                return _id;
            }
            set
            {
                _id = value;
            }
        }

        public string Name
        {
            get
            {
                return _name;
            }
            set
            {
                _name = value;
            }
        }

        public string Gender
        {
            get
            {
                return _gender;
            }
            set
            {
                _gender = value;
            }
        }

        public int Age
        {
            get
            {
                return _age;
            }
            set
            {
                _age = value;
            }
        }

        public float Fees
        {
            get
            {
                return _fees;
            }
            set
            {
                _fees = value;
            }
        }

        public StudentEntity() { }

        public StudentEntity(int id, string name, string gender, int age, float fees)
        {
            this._id = id;
            this._name = name;
            this._gender = gender;
            this._age = age;
            this._fees = fees;
        }

        public override string ToString()
        {
            return "\t\t Student Id: " + Id +
                "\t Name: " + Name +
                "\t Gender: " + Gender +
                "\t Age: " + Age +
                "\t Fees: " + Fees;
        }
    }
}
